#!/usr/bin
# -*- coding=utf-8 -*-
import operator
import  os,sys
import argparse
dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(dir)
parser = argparse.ArgumentParser()
parser.add_argument("-s","--source_path", help="the path of the rawdata file",default ="data/rawdata/")
parser.add_argument("-d","--dest_path", help="the path to save file",default="data/")
parser.add_argument("-o","--operation", help="the operation type of this dataset used for(train/dev/test)", default="dev")
args = parser.parse_args()
filepath = os.path.join(dir,args.dest_path)
raw_data_file = os.path.join(dir,args.source_path, args.operation)
def read_txt(path):
    with open(path + 'record.txt', encoding='utf-8') as f:
        text = f.read()
        f.close()
        return text

def read_ann(path):
    with open(path + 'record.ann', encoding='utf-8') as f:
        lines = f.readlines()
        entity = list()
        for line in lines:
            #
            if line[0] == 'T':
                [id, annotation, content] = line.split('\t')
                if ';' in annotation:
                    pass
                else:
                    [entity_type, start_index, end_index] = annotation.split(' ')

                entity.append([entity_type, int(start_index), int(end_index), content])
        f.close()
        entity.sort(key=operator.itemgetter(1))#對標注的實體位置的索引從小到大排序
        return entity

def merge_ann(data_file, operation):
    rawtext = read_txt(data_file)
    entities = read_ann(data_file)
    annote = list()
    last_end_index = 0
    for i in range(len(entities)):
        annote.extend((int(entities[i][1]) - last_end_index) * ['others'])
        word_len = int(entities[i][2]) - int(entities[i][1])
        if entities[i][0] == 'disorder' or entities[i][0]=='negation':
            if word_len > 1:
                annote.extend([entities[i][0]+'-B'])
                annote.extend((word_len-2) * ([entities[i][0]+'-I']))
                annote.extend([entities[i][0] + '-E'])
            else:
                annote.extend([entities[i][0] + '-S'])
        else:
            annote.extend((word_len) * (['others']))
        last_end_index = int(entities[i][2])
    annote.extend((len(rawtext) - last_end_index) * ['others'])

    text=''
    for i in range(len(rawtext)):
        text+=rawtext[i]+'\t'+annote[i]+'\n'
    write_train_file(text, operation)
    return text

def write_train_file(text,operation):
    with open(filepath + operation+'.txt','a') as f:
        f.write(text)
        f.close()

if __name__ == '__main__':
    #if os.path.isdir(raw_data_file):
    folders = os.listdir(raw_data_file)
    for folder in folders:
        print("The folder-%s is converting..." % folder)
        merge_ann(raw_data_file+'/'+folder+'/',args.operation)#train,dev,test
        print("Converting folder-%s is done!" % folder)
